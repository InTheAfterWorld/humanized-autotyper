import random
import time

from .config import Config
from .buffer import Buffer
from .delays import DelayModel
from .typos import TypoEngine
from .executor import Executor, Logger, Killer


class Pipeline:
    def __init__(self, source):
        self.src = source
        self.i = 0
        self.consumed = 0

    def next(self):
        if self.i >= len(self.src):
            return None
        c = self.src[self.i]
        self.i += 1
        self.consumed += 1
        return c

    def peek(self):
        return self.src[self.i] if self.i < len(self.src) else None

    def consume_peek(self):
        return self.next()


class LongPauseScheduler:
    def __init__(self, delays: DelayModel):
        self.delays = delays
        self.threshold = delays.sample_pareto_threshold()
        self.active = 0.0

    def add(self, seconds):
        self.active += seconds

    def should_fire(self):
        return self.active >= self.threshold

    def reset(self):
        self.threshold = self.delays.sample_pareto_threshold()
        self.active = 0.0


class AutoTyper:
    STATES = ("TYPING", "BACKSPACE_BURST", "PAUSE_SHORT", "PAUSE_LONG",
              "EDIT_PREVIOUS", "REWRITE_CHUNK")

    def __init__(self, cfg: Config, source: str, rng=random,
                 buffer=None, executor=None, logger=None, killer=None,
                 delays=None, scheduler=None):
        self.cfg = cfg
        self.rng = rng
        self.source = source
        self.pipeline = Pipeline(source)
        self.buffer = buffer if buffer is not None else Buffer("")
        self.kill = killer if killer is not None else Killer()
        self.logger = logger if logger is not None else Logger(cfg)
        self.delays = delays if delays is not None else DelayModel(cfg, rng)
        self.executor = executor if executor is not None else Executor(
            cfg, self.delays, self.logger, self.kill)
        self.sched = scheduler if scheduler is not None else LongPauseScheduler(self.delays)
        self.typos = TypoEngine(cfg, rng)
        self.last_sent = ""
        self.err_typed = ""
        self.err_intended = ""
        self.err_detect_in = -1
        self.last_edit_time = -1e18
        self.finished = False
        self.started_at = None
        self.chars_since_progress = 0
        self.stats = {"chars": 0, "source_consumed": 0, "errors": 0,
                      "corrections": 0, "bursts": 0, "short_pauses": 0,
                      "long_pauses": 0, "edits": 0, "rewrites": 0}
        self.handlers = {
            "TYPING": self._h_typing,
            "BACKSPACE_BURST": self._h_burst,
            "PAUSE_SHORT": self._h_pause_short,
            "PAUSE_LONG": self._h_pause_long,
            "EDIT_PREVIOUS": self._h_edit_previous,
            "REWRITE_CHUNK": self._h_rewrite_chunk,
        }

    def run(self):
        self.executor.start()
        self.executor.check_window()
        self.started_at = time.time()
        state = "TYPING"
        try:
            while not self.kill.killed() and not self.finished:
                state = self.handlers[state]() or "TYPING"
        except KeyboardInterrupt:
            self.kill.set()
        finally:
            self._flush_correction()
            self.executor.stop()
        elapsed = time.time() - self.started_at
        summary = dict(self.stats)
        summary["source_consumed"] = self.pipeline.consumed
        summary["elapsed_s"] = round(elapsed, 1)
        summary["final_matches_source"] = self.buffer.text == self.source
        summary["killed"] = self.kill.killed()
        return summary

    def _progress(self):
        pct = 100.0 * self.pipeline.i / max(1, len(self.source))
        if not self.cfg.verbose:
            print(f"\r[{pct:5.1f}%] chars={self.stats['chars']} "
                  f"errors={self.stats['errors']} edits={self.stats['edits']} "
                  f"rewrites={self.stats['rewrites']}", end="", flush=True)

    def _sleep(self, seconds, active=True, chunk=0.25):
        deadline = time.time() + seconds
        total = 0.0
        while True:
            if self.kill.killed():
                self.delays.note_pause(total)
                return False
            now = time.time()
            if now >= deadline:
                break
            dt = min(chunk, deadline - now)
            time.sleep(dt)
            total += dt
            if active:
                human_dt = dt * self.cfg.speed_multiplier
                self.sched.add(human_dt)
                self.delays.add_active(human_dt)
        self.delays.note_pause(total)
        return True

    def _send(self, ch, urgent=False):
        d = self.delays.sample(self.last_sent, ch)
        hold = self.cfg.urgent_hold if urgent else None
        self.executor.type_char(ch, d * 1000.0, hold=hold)
        self.buffer.type_char(ch)
        self.last_sent = ch
        self.stats["chars"] += 1
        if urgent:
            return  # 已请求停止：不再制造拟人延时，尽快补完
        self._sleep(d, active=True)

    def _retype(self, chars, allow_typos=True):
        """重打一段刚被删掉的文本。

        一旦按下删除键，这段文本就只存在于内存里了：必须打完，否则目标
        文档会缺字。若中途收到停止请求，则改用 urgent 节奏尽快补完——
        停止的延迟被限制在这一个片段之内，而不会留下半截内容。
        allow_typos=False 用于"纠正错误后重打正确内容"，此时不该再犯新错。
        """
        for ch in chars:
            urgent = self.kill.killed()
            if allow_typos:
                self._emit_intended(ch, allow_transpose=False, urgent=urgent)
            else:
                self._send(ch, urgent=urgent)

    def _return_to_end(self):
        """光标回到文末。已请求停止时不再移动（没人接着打字，省掉几百次方向键）。"""
        if self.kill.killed():
            return
        self._navigate_to(len(self.buffer.text))

    def _emit_intended(self, ch, allow_transpose=True, urgent=False):
        if self.err_detect_in >= 0:
            if ch == "\n" or self.err_detect_in == 0:
                self._flush_correction()
            else:
                self.err_detect_in -= 1
                self._send(ch, urgent=urgent)
                self.err_typed += ch
                self.err_intended += ch
                return
        nxt = self.pipeline.peek() if allow_transpose else None
        err = self.typos.roll(ch, next_char=nxt)
        if err is None:
            self._send(ch, urgent=urgent)
            return
        self.stats["errors"] += 1
        self.logger.log("TYPING", "typo", err["kind"], 0)
        if err["kind"] == "transposition":
            # 顺序对调：先打后一个源字符，再打当前字符；两个源字符都要消费掉
            self.pipeline.consume_peek()
            self._send(err["emit_first"], urgent=urgent)
            self._send(err["emit_second"], urgent=urgent)
            self.err_typed = err["emit_first"] + err["emit_second"]
            self.err_intended = err["emit_second"] + err["emit_first"]
        else:
            for pc in err["emit"]:
                self._send(pc, urgent=urgent)
            self.err_typed = err["emit"]
            self.err_intended = ch
        self.err_detect_in = err["detect_after"]

    def _flush_correction(self):
        if self.err_detect_in < 0:
            return
        self.stats["corrections"] += 1
        n = len(self.err_typed)
        self.logger.log("TYPING", "corr", f"n={n}", 0)
        for _ in range(n):
            self.executor.backspace()
            self.buffer.backspace()
            if not self.kill.killed():
                self._sleep(self.delays.backspace_delay(), active=True)
        self._retype(self.err_intended, allow_typos=False)
        self.err_typed = ""
        self.err_intended = ""
        self.err_detect_in = -1

    def _h_typing(self):
        while not self.kill.killed():
            ch = self.pipeline.next()
            if ch is None:
                self._flush_correction()
                self.finished = True
                return "TYPING"
            self._emit_intended(ch)
            if ch == "\n":
                think = self.delays.line_end_think()
                if think > 0:
                    self.logger.log("TYPING", "think", "", think * 1000)
                    self._sleep(think, active=True)
            if self.err_detect_in >= 0:
                continue
            self.chars_since_progress += 1
            if self.chars_since_progress >= 25:
                self.chars_since_progress = 0
                self._progress()
            peek = self.pipeline.peek()
            if self.sched.should_fire() and peek in (" ", "\n", None):
                self.logger.log("SCHED", "long_pause_due",
                                f"active={self.sched.active:.0f}s", 0)
                return "PAUSE_LONG"
            boundary = peek in ("\n", None)
            if boundary and not self.executor.check_window():
                # 焦点已经不在目标窗口：继续打下去就是往别的窗口里灌字
                self.logger.log("TYPING", "focus_lost", "", 0)
                return "TYPING"
            if not boundary:
                r = self.rng.random()
                if r < self.cfg.p_backspace_burst:
                    return "BACKSPACE_BURST"
                if r < self.cfg.p_backspace_burst + self.cfg.p_pause_short:
                    return "PAUSE_SHORT"
            else:
                now = time.time()
                gap_ok = (now - self.last_edit_time) >= self.cfg.edit_min_gap_s
                probs = []
                if gap_ok:
                    probs.append(("EDIT_PREVIOUS", self.cfg.p_edit_previous))
                probs.append(("REWRITE_CHUNK", self.cfg.p_rewrite_chunk))
                p_short = (self.cfg.p_pause_short_sentence
                           if ch in self.cfg.sentence_end_chars
                           else self.cfg.p_pause_short)
                probs.append(("PAUSE_SHORT", p_short))
                r = self.rng.random()
                acc = 0.0
                for st, p in probs:
                    acc += p
                    if r < acc:
                        if st == "EDIT_PREVIOUS":
                            self.last_edit_time = now
                        return st
        return "TYPING"

    def _h_burst(self):
        self.logger.log("BACKSPACE_BURST", "enter", "", 0)
        buf = self.buffer
        li = buf.current_line()
        cap = buf.cursor - buf.line_start(li)
        n = min(self.rng.randint(*self.cfg.backspace_n_range), cap)
        if n < 2:
            return "TYPING"   # 什么也没删，不计数（否则指标虚高）
        if self.kill.killed():
            return "TYPING"   # 还没动过文档，直接放弃
        self.stats["bursts"] += 1
        deleted = buf.seg(buf.cursor - n, buf.cursor)
        # 删除与重打必须成对完成，中途不再检查 kill（否则会漏字）
        for _ in range(n):
            self.executor.backspace()
            buf.backspace()
            self._sleep(self.delays.backspace_delay(), active=True)
        self._retype(deleted)
        self._flush_correction()
        self.logger.log("BACKSPACE_BURST", "exit", f"n={n}", 0)
        return "TYPING"

    def _h_pause_short(self):
        d = self.delays.pause_short()
        self.stats["short_pauses"] += 1
        self.logger.log("PAUSE_SHORT", "sleep", f"{d:.2f}s", d * 1000)
        self._sleep(d, active=True)
        return "TYPING"

    def _h_pause_long(self):
        d = self.delays.long_pause()
        self.stats["long_pauses"] += 1
        self.logger.log("PAUSE_LONG", "sleep", f"{d:.0f}s", d * 1000)
        # d is human-scale seconds; scale to wall time like every other delay.
        self._sleep(d / self.cfg.speed_multiplier, active=False,
                    chunk=self.cfg.long_sleep_chunk)
        if self.kill.killed():
            return "TYPING"
        self.delays.reset_fatigue()
        self.delays.note_pause(d)
        # 找回位置的动作必须是"左 N 再右 N"的对称位移。若 N 超过已打字符数，
        # 真实编辑器会先被文档头夹住、再往右冲过头，光标就与缓冲区错位了。
        left = min(self.rng.randint(*self.cfg.resume_left_range),
                   self.buffer.cursor)
        if left > 0:
            self.executor.nav_left(left)
            if self.kill.killed():
                return "TYPING"     # 已经要求停止，没必要再走回去
            reorient_pause = self.rng.uniform(0.3, 1.2)
            self._sleep(reorient_pause / self.cfg.speed_multiplier,
                        active=False)
            self.executor.nav_right(left)
        self.logger.log("PAUSE_LONG", "resume_ritual", f"left={left}", 0)
        reorient = self.rng.uniform(*self.cfg.resume_reorient_range)
        self._sleep(reorient / self.cfg.speed_multiplier, active=True)
        # Clear the active-time window only when the pause fully completes,
        # so the next long-pause interval starts from zero.
        self.sched.reset()
        return "TYPING"

    def _navigate_to(self, pos):
        """Move the caret to absolute buffer position `pos` using ONLY
        arrow keys. Vertical moves first (sticky-column semantics are
        mirrored by the buffer), then a horizontal correction step."""
        buf = self.buffer
        tl, tc = buf.line_col_of(pos)
        cl, _ = buf.line_col()
        if tl < cl:
            up = cl - tl
            self.executor.nav_up(up)
            buf.apply_up(up)
        elif tl > cl:
            down = tl - cl
            self.executor.nav_down(down)
            buf.apply_down(down)
        _, cc = buf.line_col()
        if tc > cc:
            self.executor.nav_right(tc - cc)
            buf.move_right(tc - cc)
        elif tc < cc:
            self.executor.nav_left(cc - tc)
            buf.move_left(cc - tc)
        assert buf.cursor == pos, f"nav mismatch {buf.cursor} != {pos}"

    def _retype_span(self, a, b):
        """选区删掉 [a,b) 再原样重打。返回 False 表示这段没被改动
        （导航未完成就被要求停止，或者删掉的内容与预期不符）。"""
        buf = self.buffer
        expected = buf.seg(a, b)
        self._navigate_to(a)
        if self.kill.killed():
            return False     # 还没删任何东西，此刻放弃是安全的
        self.executor.select_shift_right(b - a)
        removed = buf.delete_forward(b - a)
        if removed != expected:
            self.logger.log("EDIT_PREVIOUS", "delete_mismatch", repr(removed), 0)
            return False
        self._retype(expected)
        self._flush_correction()
        ok = buf.seg(a, a + len(expected)) == expected
        if not ok:
            self.logger.log("EDIT_PREVIOUS", "retype_mismatch", repr(expected), 0)
        return ok

    def _h_edit_previous(self):
        buf = self.buffer
        cur_line = buf.current_line()
        lo_n, hi_n = self.cfg.edit_lookback_range
        lo = max(0, cur_line - hi_n)
        hi = cur_line - lo_n
        if hi <= lo:
            return "TYPING"
        candidates = list(range(lo, hi))
        weights = [1.0 / (cur_line - i) for i in candidates]
        target = self.rng.choices(candidates, weights=weights, k=1)[0]
        words = buf.words_on_line(target)
        if not words:
            return "TYPING"
        a, b, wtext = self.rng.choice(words)
        kinds, ws = zip(*self.cfg.edit_op_weights)
        op = self.rng.choices(kinds, weights=ws, k=1)[0]
        self.stats["edits"] += 1
        self.logger.log("EDIT_PREVIOUS", "start", f"{op} '{wtext}' line={target}", 0)
        line_end = buf.line_end_excl_newline(target)
        if op == "replace_word":
            self._retype_span(a, b)
        elif op == "retype_clause":
            b2 = min(b + self.rng.randint(3, 10), line_end)
            self._retype_span(a, b2)
        else:
            b2 = min(a + self.rng.randint(2, 5), line_end)
            if self._retype_span(a, b2):
                c2 = min(b2 + self.rng.randint(2, 5), line_end)
                self._retype_span(b2, c2)
        self._return_to_end()
        rp = self.rng.uniform(*self.cfg.edit_return_pause)
        self._sleep(rp / self.cfg.speed_multiplier, active=True)
        self.logger.log("EDIT_PREVIOUS", "exit", "", rp * 1000)
        return "TYPING"

    def _h_rewrite_chunk(self):
        buf = self.buffer
        complete = buf.complete_line_count()
        k = min(self.rng.randint(*self.cfg.rewrite_lines_range), complete)
        if k < 1:
            return "TYPING"
        starts = buf._line_starts()
        partial_start = starts[-1]
        chunk_start = starts[-1 - k]
        chunk_text = buf.text[chunk_start:partial_start]
        if not chunk_text.endswith("\n"):
            return "TYPING"
        self.logger.log("REWRITE_CHUNK", "start", f"k={k} len={len(chunk_text)}", 0)
        self._navigate_to(chunk_start)
        if self.kill.killed():
            return "TYPING"    # 还没删任何东西，直接放弃
        self.stats["rewrites"] += 1
        self.executor.select_shift_down(k)
        removed = buf.delete_forward(len(chunk_text))
        if removed != chunk_text:
            self.logger.log("REWRITE_CHUNK", "delete_mismatch", "", 0)
            self._return_to_end()
            return "TYPING"
        self._retype(chunk_text)
        self._flush_correction()
        ok = buf.text[chunk_start:chunk_start + len(chunk_text)] == chunk_text
        if not ok:
            self.logger.log("REWRITE_CHUNK", "retype_mismatch", "", 0)
        self._return_to_end()
        self.logger.log("REWRITE_CHUNK", "exit", f"ok={ok}", 0)
        return "TYPING"
