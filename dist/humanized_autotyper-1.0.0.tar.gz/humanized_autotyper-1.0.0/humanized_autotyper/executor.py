import csv
import os
import threading
import time

from .config import Config
from .delays import DelayModel
from .keymap import SHIFT_SYMBOLS


class Killer:
    def __init__(self):
        self.event = threading.Event()

    def set(self):
        self.event.set()

    def killed(self):
        return self.event.is_set()


class Logger:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        # Always export the event log (CSV) so dry-run tuning has data too.
        exists = os.path.exists(cfg.log_file)
        self.fh = open(cfg.log_file, "a", encoding="utf-8", newline="")
        self.writer = csv.writer(self.fh)
        if not exists:
            self.writer.writerow(["ts", "state", "event", "detail", "delay_ms"])

    def log(self, state, event, detail="", delay_ms=0.0):
        if self.cfg.verbose:
            print(f"[{state}] {event} {detail} {round(delay_ms, 1)}ms")
        if self.fh:
            ts = time.strftime("%H:%M:%S")
            self.writer.writerow([ts, state, event, detail, round(delay_ms, 1)])
            self.fh.flush()

    def close(self):
        if self.fh:
            self.fh.close()


class Executor:
    def __init__(self, cfg: Config, delays: DelayModel, logger: Logger, killer: Killer):
        self.cfg = cfg
        self.delays = delays
        self.log = logger
        self.kill = killer
        self.live = not cfg.dry_run
        self._started = False
        self._warned_focus = False
        if self.live:
            from pynput.keyboard import Controller, Key, Listener, KeyCode

            self._Key = Key
            self._KeyCode = KeyCode
            self.controller = Controller()
            self.listener = Listener(on_press=self._on_press)
        else:
            self.controller = None

    def _on_press(self, key):
        name = getattr(key, "name", "")
        if name == self.cfg.kill_hotkey:
            self.kill.set()

    def start(self):
        # 幂等：CLI 在倒计时前就武装 F10，run() 之后还会再调一次
        if self.live and not self._started:
            self._started = True
            self.listener.start()

    def stop(self):
        if self.live and self._started:
            self._started = False
            try:
                self.listener.stop()
            except Exception:
                pass

    def check_window(self):
        if not self.live or not self.cfg.expected_window_title:
            return True
        try:
            import ctypes

            user32 = ctypes.windll.user32
            hwnd = user32.GetForegroundWindow()
            buf = ctypes.create_unicode_buffer(512)
            user32.GetWindowTextW(hwnd, buf, 512)
            ok = self.cfg.expected_window_title.lower() in buf.value.lower()
            if not ok and not self._warned_focus:
                print(f"WARNING: foreground window '{buf.value}' does not match "
                      f"'{self.cfg.expected_window_title}'. Aborting for safety.")
                self._warned_focus = True
                self.kill.set()
            return ok
        except Exception:
            return True

    def _sleep(self, seconds):
        time.sleep(max(0.0, seconds))

    def type_char(self, ch, delay_ms=0.0, hold=None):
        self.log.log("KEY", "char", repr(ch), delay_ms)
        if not self.live:
            return
        hold = self.delays.hold_time() if hold is None else hold
        if ch == "\n":
            self._tap_special("enter", hold)
            return
        shift = False
        base = ch
        # "İ" 这类字符 lower() 会变成两个码位，只能按原字符交给 pynput 直接注入
        if ch.isupper() and len(ch.lower()) == 1:
            base = ch.lower()
            shift = True
        elif ch in SHIFT_SYMBOLS:
            base = SHIFT_SYMBOLS[ch]
            shift = True
        key = self._KeyCode.from_char(base) if base != "" else None
        if key is None:
            return
        if shift:
            self.controller.press(self._Key.shift)
        self.controller.press(key)
        self._sleep(hold)
        self.controller.release(key)
        if shift:
            self.controller.release(self._Key.shift)

    def _tap_special(self, name, hold=None):
        self.log.log("KEY", "tap", name, 0)
        if not self.live:
            return
        key = getattr(self._Key, name)
        self.controller.press(key)
        self._sleep(hold if hold is not None else self.delays.nav_delay())
        self.controller.release(key)

    def backspace(self):
        self._tap_special("backspace")

    def delete_key(self):
        self._tap_special("delete")

    def nav_left(self, n=1):
        for _ in range(n):
            self._tap_special("left")

    def nav_right(self, n=1):
        for _ in range(n):
            self._tap_special("right")

    def nav_up(self, n=1):
        for _ in range(n):
            self._tap_special("up")

    def nav_down(self, n=1):
        for _ in range(n):
            self._tap_special("down")

    def select_shift_down(self, n=1):
        self.log.log("SELECT", "shift+down", f"x{n}", 0)
        if not self.live:
            return
        self.controller.press(self._Key.shift)
        for _ in range(n):
            self.controller.press(self._Key.down)
            self._sleep(self.delays.nav_delay())
            self.controller.release(self._Key.down)
        self.controller.release(self._Key.shift)

    def select_shift_right(self, n=1):
        self.log.log("SELECT", "shift+right", f"x{n}", 0)
        if not self.live:
            return
        self.controller.press(self._Key.shift)
        for _ in range(n):
            self.controller.press(self._Key.right)
            self._sleep(self.delays.nav_delay())
            self.controller.release(self._Key.right)
        self.controller.release(self._Key.shift)
