"""report.py — audit observed behaviour against configured probabilities.

Run a dry-run first to export an event CSV, then:

    py report.py smoke_log.csv

Reads the event log written by Logger (ts,state,event,detail,delay_ms) and
prints observed vs. expected frequencies for the key humanization knobs.
"""
import argparse
import csv
from collections import Counter

from .config import Config


def load(path):
    rows = []
    with open(path, "r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        for line in reader:
            rows.append(line)
    return rows


def main(argv=None):
    ap = argparse.ArgumentParser(description="Audit autotyper CSV event log")
    ap.add_argument("log", help="path to exported CSV event log")
    args = ap.parse_args(argv)

    rows = load(args.log)
    cfg = Config()
    events = Counter((r["state"], r["event"]) for r in rows)
    chars = sum(1 for r in rows if r["event"] == "char")
    legal = sum(1 for r in rows
                if r["event"] == "char" and r["detail"] != "'\\n'")
    errors = events.get(("TYPING", "typo"), 0)
    corrections = events.get(("TYPING", "corr"), 0)
    bursts = events.get(("BACKSPACE_BURST", "enter"), 0)
    pauses = events.get(("PAUSE_SHORT", "sleep"), 0)
    long_pauses = events.get(("PAUSE_LONG", "sleep"), 0)
    edits = events.get(("EDIT_PREVIOUS", "start"), 0)
    rewrites = events.get(("REWRITE_CHUNK", "start"), 0)

    delays = sorted(
        float(r["delay_ms"]) for r in rows
        if r["event"] == "char" and r.get("delay_ms") not in (None, "")
    )

    def line(name, observed, target_frac, n, note=""):
        obs = 100.0 * observed / n if n else 0.0
        print(f"{name:26s} obs {obs:6.2f}%   cfg {target_frac * 100:6.2f}%   {note}")

    print(f"rows        : {len(rows)}")
    print(f"chars       : {chars}  (errors {errors}, corrections {corrections})")
    print()
    line("typo rate", errors, cfg.p_typo, legal,
         f"(boost x{cfg.typo_autocorr_boost} for {cfg.typo_autocorr_window} "
         f"chars after a typo)")
    line("backspace burst", bursts, cfg.p_backspace_burst, chars,
         f"n in {cfg.backspace_n_range}")
    line("short pause (mid-line)", pauses, cfg.p_pause_short, chars)
    print(f"{'long pauses':26s} {long_pauses} (Pareto x_min="
          f"{cfg.long_pause_xmin:.0f}s alpha={cfg.long_pause_alpha})")
    print(f"{'edit previous':26s} {edits}  p={cfg.p_edit_previous} at line end")
    print(f"{'rewrite chunk':26s} {rewrites}  p={cfg.p_rewrite_chunk} at line end")

    print()
    if delays:
        mid = delays[len(delays) // 2]
        p95 = delays[int(len(delays) * 0.95)]
        print(f"per-char delay_ms: n={len(delays)} min={delays[0]:.1f} "
              f"median={mid:.1f} p95={p95:.1f} max={delays[-1]:.1f} "
              f"(human clip {cfg.delay_clip[0]*1000:.0f}.."
              f"{cfg.delay_clip[1]*1000:.0f}; divide these by speed_multiplier "
              f"to get wall time)")
    if errors and not corrections:
        print("\nWARNING: typos happened but no corrections logged — check "
              "the correction path.")


if __name__ == "__main__":
    main()