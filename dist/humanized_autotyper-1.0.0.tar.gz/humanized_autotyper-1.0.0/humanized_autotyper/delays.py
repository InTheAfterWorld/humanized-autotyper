import math
import random

from .config import Config
from .keymap import SHIFT_SYMBOLS


class DelayModel:
    def __init__(self, cfg: Config, rng=random):
        self.cfg = cfg
        self.rng = rng
        self.ln_mu = math.log(cfg.delay_mu)
        self.fatigue_minutes = 0.0
        self.warmup_left = 0
        self.burst_left = 0
        self.burst_refractory = 0

    def add_active(self, seconds):
        self.fatigue_minutes += seconds / 60.0

    def note_pause(self, seconds):
        if seconds >= self.cfg.warmup_min_pause:
            self.warmup_left = self.cfg.warmup_chars

    def reset_fatigue(self):
        self.fatigue_minutes = 0.0

    def _fatigue(self):
        f = 1.0 + self.cfg.fatigue_rate * self.fatigue_minutes
        return min(self.cfg.fatigue_cap, f)

    def _warmup(self):
        if self.warmup_left <= 0:
            return 1.0, False
        frac = self.warmup_left / max(1, self.cfg.warmup_chars)
        self.warmup_left -= 1
        return 1.0 + (self.cfg.warmup_factor - 1.0) * frac, True

    def _roll_burst(self, cur):
        c = self.cfg
        if self.burst_left > 0:
            self.burst_left -= 1
            return True
        if self.burst_refractory > 0:
            self.burst_refractory -= 1
            return False
        if cur and cur != "\n" and self.rng.random() < c.p_burst_enter:
            self.burst_left = self.rng.randint(*c.burst_len_range) - 1
            self.burst_refractory = self.burst_left + self.rng.randint(10, 30)
            return True
        return False

    def sample(self, prev, cur):
        c = self.cfg
        sigma = c.delay_ln_sigma
        factor = 1.0

        bursting = self._roll_burst(cur)
        if bursting:
            factor *= c.burst_speed_factor
            sigma *= 0.5

        if prev == "\n":
            factor *= c.factor_after_newline
        elif prev and prev in c.sentence_end_chars:
            factor *= c.factor_after_sentence

        if cur != "\n":
            if cur.isupper() or (not cur.isspace() and cur in SHIFT_SYMBOLS):
                factor *= c.factor_shift
            if cur == " ":
                factor *= c.factor_space
                gap = max(0.0, self.rng.gauss(c.word_gap_mu, c.word_gap_sigma))
            else:
                gap = 0.0
            if cur == prev and cur.isalnum():
                factor *= c.factor_repeat
        else:
            gap = 0.0

        d = math.exp(self.rng.gauss(self.ln_mu, sigma)) * factor
        d *= self._fatigue()
        wf, _ = self._warmup()
        d *= wf
        # clamp the human-scale latency first, then map to wall-clock time,
        # so speed_multiplier doesn't get destroyed by the clip bounds.
        d = min(max(d, c.delay_clip[0]), c.delay_clip[1])
        d /= c.speed_multiplier
        if not bursting:
            d += gap / c.speed_multiplier
        return d

    def hold_time(self):
        t = max(0.02, self.rng.gauss(self.cfg.hold_mu, self.cfg.hold_sigma))
        return t / self.cfg.speed_multiplier

    def nav_delay(self):
        t = max(0.02, self.rng.gauss(self.cfg.nav_delay_mu, self.cfg.nav_delay_sigma))
        return t / self.cfg.speed_multiplier

    def backspace_delay(self):
        t = max(
            0.02,
            self.rng.gauss(
                self.cfg.backspace_delay_mu, self.cfg.backspace_delay_sigma
            ),
        )
        return t / self.cfg.speed_multiplier

    def pause_short(self):
        c = self.cfg
        d = math.exp(self.rng.gauss(c.pause_short_ln_mu, c.pause_short_ln_sigma))
        lo, hi = c.pause_short_clip
        return min(max(d, lo), hi) / c.speed_multiplier

    def line_end_think(self):
        c = self.cfg
        if self.rng.random() >= c.line_end_think_prob:
            return 0.0
        lo, hi = c.line_end_think_range
        return self.rng.uniform(lo, hi) / c.speed_multiplier

    def long_pause(self):
        c = self.cfg
        u = max(self.rng.random(), 1e-9)
        d = c.long_pause_xmin * (u ** (-1.0 / c.long_pause_alpha))
        return min(d, c.long_pause_cap)

    def sample_pareto_threshold(self):
        return self.long_pause()
