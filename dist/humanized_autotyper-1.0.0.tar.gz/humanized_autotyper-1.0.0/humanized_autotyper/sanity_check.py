import os
import random
import time

from .config import Config
from .buffer import Buffer
from .delays import DelayModel
from .keymap import unsupported_chars
from .typos import TypoEngine, is_typoable
from .machine import AutoTyper
from .main import DEMO_SOURCE, source_problem


def test_buffer():
    b = Buffer("hello\nworld")
    for ch in "!!!":
        b.type_char(ch)
    assert b.text == "hello\nworld!!!" and b.cursor == 14
    b.backspace()
    assert b.text == "hello\nworld!!" and b.cursor == 13
    b.to_line_start()
    assert b.line_col() == (1, 0)
    b.apply_up(1)
    assert b.line_col() == (0, 0)
    b.move_right(3)
    assert b.seg(b.cursor - 3, b.cursor) == "hel"
    assert b.complete_line_count() == 1 and b.line_count() == 2
    assert b.line_end_excl_newline(0) == 5
    ws = Buffer("def foo_bar(x):\n    return x").words_on_line(0)
    assert "foo_bar" in [w[2] for w in ws]
    print("PASS buffer")


def test_delays():
    cfg = Config()
    rng = random.Random(1)
    dm = DelayModel(cfg, rng)
    s = sorted(dm.sample("", "a") for _ in range(5000))
    med, p95 = s[2500], s[4750]
    assert 0.07 <= med <= 0.16 and p95 <= cfg.delay_clip[1]
    d_nl = sum(dm.sample("\n", "a") for _ in range(500)) / 500
    d_rep = sum(dm.sample("a", "a") for _ in range(500)) / 500
    assert d_nl > med * 1.8
    ps = sorted(dm.pause_short() for _ in range(2000))
    assert cfg.pause_short_clip[0] <= ps[0] + 1e-9 <= ps[-1] <= cfg.pause_short_clip[1] + 1e-9
    lp = sorted(dm.long_pause() for _ in range(2000))
    assert lp[-1] <= cfg.long_pause_cap + 1e-9 and lp[1000] >= cfg.long_pause_xmin
    dm.add_active(600)
    assert dm._fatigue() > 1.0
    dm.note_pause(10)
    assert dm.warmup_left == cfg.warmup_chars
    print(f"PASS delays median={med*1000:.0f}ms p95={p95*1000:.0f}ms "
          f"afterNL={d_nl*1000:.0f}ms repeat={d_rep*1000:.0f}ms")


def test_typos():
    cfg = Config()
    rng = random.Random(2)
    te = TypoEngine(cfg, rng)
    kinds = {}
    n = 4000
    for _ in range(n):
        r = te.roll("d", next_char="x")
        if r:
            assert r["kind"] in ("adjacent", "double", "transposition", "random")
            kinds[r["kind"]] = kinds.get(r["kind"], 0) + 1
    rate = sum(kinds.values()) / n
    assert 0.004 <= rate <= 0.03 and kinds.get("transposition", 0) > 0
    assert te.roll("\n", next_char=None) is None
    print(f"PASS typos rate={rate:.3f} kinds={kinds}")


def fast_cfg(**over):
    base = dict(
        dry_run=True, speed_multiplier=300.0, countdown_seconds=0,
        line_end_think_prob=0.02, pause_short_ln_mu=-4.6,
        pause_short_clip=(0.002, 0.01), long_pause_cap=0.4,
        edit_min_gap_s=0.0, p_edit_previous=0.06, p_rewrite_chunk=0.06,
        log_file=os.devnull,
    )
    base.update(over)
    return Config(**base)


def test_full_dry_run():
    cfg = fast_cfg()
    t0 = time.time()
    typer = AutoTyper(cfg, DEMO_SOURCE, rng=random.Random(42))
    typer.sched.threshold = 0.05
    s = typer.run()
    took = time.time() - t0
    assert s["final_matches_source"], "BUFFER != SOURCE after full run"
    assert s["source_consumed"] == len(DEMO_SOURCE)
    assert s["errors"] > 0 and s["corrections"] > 0
    assert s["long_pauses"] >= 1
    assert took < 120
    print(f"PASS full_dry_run {s} in {took:.1f}s")


def _primed_typer(cfg, upto):
    typer = AutoTyper(cfg, DEMO_SOURCE, rng=random.Random(7))
    typer.buffer.text = DEMO_SOURCE[:upto]
    typer.buffer.cursor = upto
    typer.pipeline.i = upto
    typer.last_sent = DEMO_SOURCE[upto - 1] if upto else ""
    return typer


def test_edit_previous_unit():
    cfg = fast_cfg()
    for upto in (300, 500, 700):
        t = _primed_typer(cfg, upto)
        before = t.buffer.text
        fired = False
        for _ in range(30):
            t.last_edit_time = -1e18
            t._h_edit_previous()
            if t.stats["edits"] > 0:
                fired = True
                break
        assert fired, f"edit never fired at upto={upto}"
        assert t.buffer.text == before, "EDIT_PREVIOUS changed committed text"
        assert t.buffer.cursor == len(before), "cursor not at doc end after edit"
        assert t.err_detect_in < 0
    print("PASS edit_previous_unit")


def test_rewrite_chunk_unit():
    cfg = fast_cfg()
    for upto in (400, 700):
        t = _primed_typer(cfg, upto)
        before = t.buffer.text
        t._h_rewrite_chunk()
        assert t.buffer.text == before, "REWRITE_CHUNK changed committed text"
        assert t.buffer.cursor == len(before)
        assert t.stats["rewrites"] >= 1
    print("PASS rewrite_chunk_unit")


def test_burst_unit():
    cfg = fast_cfg()
    t = _primed_typer(cfg, 500)
    # 光标必须落在行中间：行首只剩 1 个字符时爆发本来就删不动
    t.buffer.text = "x" * 40
    t.buffer.cursor = 40
    before = t.buffer.text
    t._h_burst()
    assert t.stats["bursts"] == 1
    assert t.buffer.text == before, "BACKSPACE_BURST changed text net effect"
    print("PASS burst_unit")


def test_pause_long_unit():
    cfg = fast_cfg()
    t = _primed_typer(cfg, 400)
    before = t.buffer.text
    cur_before = t.buffer.cursor
    t.delays.reset_fatigue()
    t.sched.active = 999.0
    r = t._h_pause_long()
    assert r == "TYPING"
    assert t.buffer.text == before and t.buffer.cursor == cur_before
    assert t.sched.active < 0.5
    print("PASS pause_long_unit")


class NavRecorder:
    """只记录方向键次数，不发送任何按键。"""
    def __init__(self):
        self.taps = []

    def nav_left(self, n=1):
        self.taps.append(("left", n))

    def nav_right(self, n=1):
        self.taps.append(("right", n))

    def nav_up(self, n=1):
        self.taps.append(("up", n))

    def nav_down(self, n=1):
        self.taps.append(("down", n))


def test_pause_long_ritual_clamped():
    """光标在文首附近时，"左 N 再右 N"的找回位置动作不能超过已打字符数：
    超出部分会被编辑器在文档头夹住，回程就冲过头，光标与缓冲区错位。"""
    cfg = fast_cfg()
    cfg.resume_left_range = (60, 60)
    cfg.long_pause_xmin = cfg.long_pause_cap = 1.0
    for upto in (0, 10, 30, 200):
        t = _primed_typer(cfg, upto)
        rec = NavRecorder()
        t.executor = rec
        t.sched.active = 1e9
        before = t.buffer.text
        t._h_pause_long()
        left = sum(n for k, n in rec.taps if k == "left")
        right = sum(n for k, n in rec.taps if k == "right")
        assert left == right, f"左移/右移不对称: {left} vs {right}"
        assert left <= upto, f"左移 {left} 次 > 已打 {upto} 字符"
        assert t.buffer.text == before and t.buffer.cursor == len(before)
    print("PASS pause_long_ritual_clamped")


def test_burst_no_fake_count():
    """行首只剩 1 个字符时删不动，这种"没发生的爆发"不能计入统计。"""
    cfg = fast_cfg()
    t = AutoTyper(cfg, DEMO_SOURCE, rng=random.Random(3))
    t.buffer.text = "a"
    t.buffer.cursor = 1
    t.pipeline.i = 1
    for _ in range(20):
        t._h_burst()
    assert t.stats["bursts"] == 0 and t.buffer.text == "a"
    print("PASS burst_no_fake_count")


def test_transposition_payload():
    """换序错误的返回结构必须自洽：先打后一个字符，再打当前字符。"""
    te = TypoEngine(Config(), random.Random(3))
    for _ in range(20000):
        r = te.roll("d", next_char="x")
        if r and r["kind"] == "transposition":
            assert r["emit_first"] == "x", r
            assert r["emit_second"] == "d", r
            assert r["typed_len"] == 2, r
            break
    else:
        raise AssertionError("20000 次都没抽到 transposition")
    print("PASS transposition_payload")


def test_kill_mid_edit_keeps_text():
    """停止请求正好落在"已删除、还没重打"之间时，文档不能缺字。"""
    cfg = fast_cfg()
    for upto in (300, 500, 700):
        t = _primed_typer(cfg, upto)
        before = t.buffer.text
        ex = t.executor
        orig_select = ex.select_shift_right

        def kill_on_select(n=1, _t=t, _orig=orig_select):
            _t.kill.set()          # 模拟停止请求恰好在这时到达
            return _orig(n)

        ex.select_shift_right = kill_on_select
        for _ in range(30):
            # 抽中的目标行可能没有可改的单词，那就再抽一次
            t.last_edit_time = -1e18
            t._h_edit_previous()
            if t.kill.killed():
                break
        t._flush_correction()
        assert t.kill.killed(), f"没走到删除路径 (upto={upto})"
        assert t.buffer.text == before, f"停止时删掉的片段没补回来 (upto={upto})"
    print("PASS kill_mid_edit_keeps_text")


def test_kill_mid_burst_keeps_text():
    """回删爆发中途收到停止请求：已删的片段必须补回。"""
    cfg = fast_cfg()
    t = _primed_typer(cfg, 500)
    t.buffer.text = "x" * 40        # 光标在行中，爆发才有得删
    t.buffer.cursor = 40
    before = t.buffer.text
    ex = t.executor
    orig_backspace = ex.backspace
    calls = {"n": 0}

    def backspace(_t=t):
        calls["n"] += 1
        if calls["n"] == 2:
            _t.kill.set()
        return orig_backspace()

    ex.backspace = backspace
    t._h_burst()
    assert t.stats["bursts"] == 1
    assert t.buffer.text == before, "回删爆发被停止后没有补回文本"
    print("PASS kill_mid_burst_keeps_text")


def test_source_guard():
    """\r 之类的控制字符必须在启动前就被拒绝（dry-run 也照样拒）。"""
    assert unsupported_chars("a\nb\tc") == []
    assert unsupported_chars("a\rb") == [(1, "\r")]
    assert [i for i, _ in unsupported_chars("x\x00y\x0bz")] == [1, 3]
    assert source_problem("") is not None
    assert source_problem("   ") is not None
    assert source_problem("a\rb") is not None
    assert source_problem(DEMO_SOURCE) is None
    print("PASS source_guard")


def test_mixed_text_dry_run():
    """中英混排 + emoji + 制表符：缓冲区必须逐字符等于源文本。"""
    src = "你好，world！\n\tdef 函数(x):  # 😀 ok?\n" * 8
    cfg = fast_cfg()
    t = AutoTyper(cfg, src, rng=random.Random(11))
    t.sched.threshold = 0.05
    s = t.run()
    assert s["final_matches_source"], "中英混排 + emoji 跑完不一致"
    assert s["source_consumed"] == len(src)
    print(f"PASS mixed_text_dry_run chars={s['chars']} errors={s['errors']} "
          f"edits={s['edits']} rewrites={s['rewrites']}")


def main():
    test_buffer()
    test_delays()
    test_typos()
    test_full_dry_run()
    test_edit_previous_unit()
    test_rewrite_chunk_unit()
    test_burst_unit()
    test_pause_long_unit()
    test_pause_long_ritual_clamped()
    test_burst_no_fake_count()
    test_transposition_payload()
    test_kill_mid_edit_keeps_text()
    test_kill_mid_burst_keeps_text()
    test_source_guard()
    test_mixed_text_dry_run()
    print("ALL SANITY CHECKS PASSED")


if __name__ == "__main__":
    main()
