import re


class Buffer:
    def __init__(self, text=""):
        self.text = text
        self.cursor = len(text)

    def type_char(self, c):
        self.text = self.text[: self.cursor] + c + self.text[self.cursor :]
        self.cursor += 1

    def backspace(self):
        if self.cursor > 0:
            self.text = self.text[: self.cursor - 1] + self.text[self.cursor :]
            self.cursor -= 1

    def delete_forward(self, n):
        n = min(n, len(self.text) - self.cursor)
        removed = self.text[self.cursor : self.cursor + n]
        self.text = self.text[: self.cursor] + self.text[self.cursor + n :]
        return removed

    def move_left(self, n=1):
        self.cursor = max(0, self.cursor - n)

    def move_right(self, n=1):
        self.cursor = min(len(self.text), self.cursor + n)

    def to_line_start(self):
        self.cursor = self.line_start(self.current_line())

    def to_doc_end(self):
        self.cursor = len(self.text)

    def _line_starts(self):
        starts = [0]
        for i, ch in enumerate(self.text):
            if ch == "\n":
                starts.append(i + 1)
        return starts

    def line_count(self):
        return len(self._line_starts())

    def current_line(self):
        return self.text.count("\n", 0, self.cursor)

    def line_start(self, li):
        return self._line_starts()[li]

    def line_end_excl_newline(self, li):
        starts = self._line_starts()
        start = starts[li]
        if li + 1 < len(starts):
            return starts[li + 1] - 1
        return len(self.text)

    def line_text(self, li):
        return self.text[self.line_start(li) : self.line_end_excl_newline(li)]

    def line_col(self):
        li = self.current_line()
        return li, self.cursor - self.line_start(li)

    def line_col_of(self, pos):
        pos = max(0, min(len(self.text), pos))
        li = self.text.count("\n", 0, pos)
        return li, pos - self.line_start(li)

    def apply_up(self, n=1):
        li, col = self.line_col()
        tl = max(0, li - n)
        start = self.line_start(tl)
        length = self.line_end_excl_newline(tl) - start
        self.cursor = start + min(col, length)

    def apply_down(self, n=1):
        li, col = self.line_col()
        starts = self._line_starts()
        tl = min(li + n, len(starts) - 1)
        start = starts[tl]
        length = self.line_end_excl_newline(tl) - start
        self.cursor = start + min(col, length)

    def complete_line_count(self):
        return self.text.count("\n")

    def words_on_line(self, li):
        line = self.line_text(li)
        base = self.line_start(li)
        out = []
        for m in re.finditer(r"[A-Za-z_][A-Za-z0-9_]{2,}", line):
            out.append((base + m.start(), base + m.end(), m.group()))
        return out

    def seg(self, a, b):
        return self.text[a:b]
