SHIFT_SYMBOLS = {
    "~": "`",
    "!": "1",
    "@": "2",
    "#": "3",
    "$": "4",
    "%": "5",
    "^": "6",
    "&": "7",
    "*": "8",
    "(": "9",
    ")": "0",
    "_": "-",
    "+": "=",
    "{": "[",
    "}": "]",
    "|": "\\",
    ":": ";",
    '"': "'",
    "<": ",",
    ">": ".",
    "?": "/",
}

ADJACENT = {
    "q": "wa",
    "w": "qeas",
    "e": "wrsd",
    "r": "etdf",
    "t": "ryfg",
    "y": "tugh",
    "u": "yihj",
    "i": "uojk",
    "o": "ipkl",
    "p": "ol",
    "a": "qwsz",
    "s": "awedxz",
    "d": "serfcx",
    "f": "drtgv",
    "g": "ftyhb",
    "h": "gyujn",
    "j": "huikm",
    "k": "jiolm",
    "l": "kop",
    "z": "asx",
    "x": "zsdc",
    "c": "xdfv",
    "v": "cfgb",
    "b": "vghn",
    "n": "bhjm",
    "m": "njk",
    "1": "2q",
    "2": "13w",
    "3": "24e",
    "4": "35r",
    "5": "46t",
    "6": "57y",
    "7": "68u",
    "8": "79i",
    "9": "80o",
    "0": "9p",
}

# 允许出现的控制字符（换行走 Enter 键，Tab 走 Tab 键）
ALLOWED_CONTROL = ("\n", "\t")


def unsupported_chars(text):
    """返回无法可靠键入的字符：[(下标, 字符)]。

    除 \n \t 之外的 C0/C1 控制字符（\r \x0b \x0c \x1b \x7f …）在编辑器里
    的行为各不相同（有的被忽略、有的当成换行），会让"虚拟缓冲区 = 文档"
    这一前提失效，因此启动前直接拒绝，而不是让它静默地打字打歪。
    """
    return [(i, ch) for i, ch in enumerate(text)
            if (ord(ch) < 0x20 or ord(ch) == 0x7f) and ch not in ALLOWED_CONTROL]

